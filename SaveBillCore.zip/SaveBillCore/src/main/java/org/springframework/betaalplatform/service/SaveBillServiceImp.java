package org.springframework.betaalplatform.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.betaalplatform.model.Evenement;
import org.springframework.betaalplatform.repository.EvenementRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class SaveBillServiceImp implements SaveBillService{

	@Autowired
	private EvenementRepository evenementRepository;
	
	@Transactional
	public void save(Evenement evenement) {
		evenementRepository.save(evenement);
	}

	@Transactional
	public void delete(Evenement evenement) {
		evenementRepository.delete(evenement);
	}

	@Transactional
	public Collection<Evenement> findAll() {
		return evenementRepository.findAll();
	}

	@Transactional
	public Evenement findById(Long id) {
		return evenementRepository.findById(id);
	}

}
