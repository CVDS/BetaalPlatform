package org.springframework.betaalplatform.repository;

public interface FactuurRepository {

}
