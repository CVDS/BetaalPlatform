package org.springframework.betaalplatform.model;

public enum Status {
	BETAALD, NIET_BETAALD,TEVEELBETAALD,TEWEINIGBETAALD
}
