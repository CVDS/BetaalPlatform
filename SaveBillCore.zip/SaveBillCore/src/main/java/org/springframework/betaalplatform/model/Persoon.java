package org.springframework.betaalplatform.model;

public class Persoon extends Identifier{

}
