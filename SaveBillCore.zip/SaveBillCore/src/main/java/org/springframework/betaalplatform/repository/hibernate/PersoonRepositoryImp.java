package org.springframework.betaalplatform.repository.hibernate;

import org.springframework.betaalplatform.repository.PersoonRepository;

public class PersoonRepositoryImp implements PersoonRepository{

}
