package org.springframework.betaalplatform.repository;

import java.util.Collection;

import org.springframework.betaalplatform.model.Evenement;

public interface EvenementRepository {
	public void save(Evenement evenement);
	public void delete(Evenement evenement);
	public Collection<Evenement> findAll();
	public Evenement findById(Long id);
}
