package org.springframework.betaalplatform.repository;

public interface RekeningRepository {

}
