package org.springframework.betaalplatform.repository.hibernate;

import org.springframework.betaalplatform.repository.FactuurRepository;

public class FactuurRepositoryImp implements FactuurRepository{

}
