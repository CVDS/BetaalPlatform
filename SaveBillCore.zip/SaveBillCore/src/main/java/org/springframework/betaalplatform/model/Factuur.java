package org.springframework.betaalplatform.model;

public class Factuur extends Identifier{

}
