package org.springframework.betaalplatform.repository.hibernate;

import org.springframework.betaalplatform.repository.RekeningRepository;

public class RekeningRepositoryImp implements RekeningRepository{

}
