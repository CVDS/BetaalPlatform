package org.springframework.betaalplatform.model;

import java.util.Collection;
import java.util.Iterator;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="T_EVENEMENT")
public class Evenement extends Identifier{
	
	@Column(name="naam")
	@org.hibernate.annotations.AccessType("property")
	private String naam;
	@Column(name="startdatum")
	@org.hibernate.annotations.AccessType("property")
	private String startDatum;
	@Column(name="einddatum")
	@org.hibernate.annotations.AccessType("property")
	private String eindDatum;
	
	private Status status;
	private Rekening rekening;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="id")
	private Collection<Factuur> facturen;
	
	public Evenement(){}
	
	/*
 	public Evenement(String naam, String startDatum, String eindDatum, Rekening rekening){
		setNaam(naam);
		setStartDatum(startDatum);
		setEindDatum(eindDatum);
		setStatus(Status.NIET_BETAALD);
		setRekening(rekening);
		facturen = new ArrayList<>();
	}*/

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}
	
	public String getNaam(String naam){
		return naam;
	}
	
	public void setNaam(String naam){
		this.naam = naam;
	}
	
	public void setStartDatum(String startDatum){
		this.startDatum = startDatum;
	}
	
	public void setEindDatum(String eindDatum){
		this.eindDatum = eindDatum;
	}
	
	public void setRekening(Rekening rekening){
		this.rekening = rekening;
	}
	
	public void addFactuur(Factuur factuur){
		facturen.add(factuur);
	}
	
	public void deleteFactuur(Factuur factuur){
		facturen.remove(factuur);
	}
	
	public Collection<Factuur> getFacturen(){
		return facturen;
	}
	
	public Factuur getFactuur(Identifier id){
		 Iterator<Factuur> i = facturen.iterator();
		 boolean found = false;
		 Factuur factuur = null;
		 while(i.hasNext() && !found){
			 factuur = i.next();
			 if(factuur.getId() == id.getId()){
				 found = true;
			 }
		 }
		 if(!found){
			 //throw not found exception
			 factuur = null;
		 }
		 return factuur;
	}
	
}
