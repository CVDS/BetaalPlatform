package org.springframework.betaalplatform.repository.hibernate;

import java.util.Collection;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.betaalplatform.model.Evenement;
import org.springframework.betaalplatform.repository.EvenementRepository;
import org.springframework.stereotype.Repository;

@Repository
public class EvenementRepositoryImp implements EvenementRepository{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory){
		this.sessionFactory = sessionFactory;
	}
	
	public void save(Evenement evenement) {
		sessionFactory.getCurrentSession().save(evenement);
	}

	public void delete(Evenement evenement) {
		Evenement deleteEvenement = findById(evenement.getId());
		sessionFactory.getCurrentSession().delete(deleteEvenement);	
	}

	public Evenement findById(Long id) {
		Evenement evenement = (Evenement) sessionFactory.getCurrentSession().get(Evenement.class, id);
		return evenement;
	}

	public Collection<Evenement> findAll() {
		Collection<Evenement> evenementen = sessionFactory.getCurrentSession().createQuery("from evenement").list();
		return evenementen;
	}

}
