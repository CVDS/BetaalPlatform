package org.springframework.betaalplatform.repository;

public interface PersoonRepository {

}
