package org.springframework.betaalplatform.model;

public class Rekening{

}
