package org.springframework.betaalplatform.service;

import org.hibernate.cfg.Configuration;
import org.springframework.betaalplatform.model.Evenement;
import org.springframework.betaalplatform.repository.EvenementRepository;
import org.springframework.betaalplatform.repository.hibernate.EvenementRepositoryImp;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("/spring/application-config.xml");
	    SaveBillService service = (SaveBillService) context.getBean("savebillService");
	}

}
